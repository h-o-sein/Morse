
export default class Config {
	static get appId() {
		return '9DA1B1F4-0BE6-4DA8-82C5-2E81DAB56F23';
	}
}