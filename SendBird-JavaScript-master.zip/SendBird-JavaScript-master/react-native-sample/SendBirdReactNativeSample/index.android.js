import React from 'react';
import {
  AppRegistry
} from 'react-native';

import Main from './src/main';

AppRegistry.registerComponent('SendBirdReactNativeSample', () => Main);
