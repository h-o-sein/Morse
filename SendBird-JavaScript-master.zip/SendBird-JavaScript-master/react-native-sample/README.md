# Sample JavaScript React-Native Basic

## NOTICE!

This sample is deprecated and not supported any longer.  
You can see the latest React Native sample in [SendBird React Native Redux sample](https://github.com/smilefam/SendBird-JavaScript/tree/master/react-native-redux-sample).