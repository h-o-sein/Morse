Changelog
=========

## 21/09/2016
### update
 * add CHANGELOG.md
 * `SDK v2` replaced by `SDK v3`
