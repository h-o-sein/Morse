# JavaScript Web Basic Sample

## NOTICE!

This sample is deprecated and not supported any longer.  
You can see the latest web basic sample in [SendBird Web Basic Sample](https://github.com/smilefam/SendBird-JavaScript/tree/master/web-basic-sample).